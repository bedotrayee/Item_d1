import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.component.html',
  styleUrls: ['./create-order.component.css']
})
export class CreateOrderComponent implements OnInit {
  Iname='';
         Quantity='';
  Price=' ';
  arr=[];
  constructor() { }

  ngOnInit() {
  }
 
create(){
  var Item={Quantity:this.Quantity, Price:this.Price,Date:new Date() };
  this.arr.push(Item);
   
  localStorage.setItem("array",JSON.stringify(this.arr));
   console.log(this.arr);

}
}
