import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {T1Component} from './t1/t1.component'
import {T2Component} from './t2/t2.component'
import { OrderPortalComponent } from './order-portal/order-portal.component';
import { CreateOrderComponent } from './create-order/create-order.component';
import { AddItemComponent } from './add-item/add-item.component';
 
const routes: Routes = [{path:'t1',component:T1Component},
{path:'t2',component:T2Component},
{path:'order-portal',component:OrderPortalComponent },
{path:'create-order',component:CreateOrderComponent},
{path:'add-item',component:AddItemComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[T1Component,T2Component,OrderPortalComponent,CreateOrderComponent,AddItemComponent];
