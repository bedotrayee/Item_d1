import { Component, OnInit } from '@angular/core';
import { splitClasses } from '@angular/compiler';

@Component({
  selector: 'app-t2',
  templateUrl: './t2.component.html',
  styleUrls: ['./t2.component.css']
})
export class T2Component implements OnInit {
  name='';
  p:number=0;
    contact='';
    address='';
  adata=[];
  constructor() { }

  ngOnInit() {
    this. adata=JSON.parse(localStorage.getItem("array"));
 
  }
  passindex(i: number){
    this.p=i;
    console.log(this.p);
   } 
edit(){
 /* //localStorage.setItem("name",this.name);
  //localStorage.setItem("contact",this.contact);
  //localStorage.setItem("address",this.address);
  var newdata={name:this.name,contact:this.contact,address:this.address}
  this.adata[2].push(newdata);
//localStorage.clear();
  localStorage.setItem("array",JSON.stringify(this.adata));
  console.log(this.adata);*/
}

 del(){
   
console.log(this.adata.splice(this.p,1));

 }
 

}