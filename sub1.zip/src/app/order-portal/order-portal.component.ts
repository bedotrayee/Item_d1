import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-portal',
  templateUrl: './order-portal.component.html',
  styleUrls: ['./order-portal.component.css']
})
export class OrderPortalComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}
